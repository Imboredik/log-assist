(function () {
  const originalConsoleError = console.error;
  const originalConsoleWarn = console.warn;
  let errorScreenshotTimeout = null;
  
  window.__logAssistIsLogging = false;
  window.__logAssistHasError = false;

  window.addEventListener("message", (event) => {
    if (event.source !== window) return;

    if (event.data?.type === "log-assist-started") {
      window.__logAssistIsLogging = true;
      window.__logAssistHasError = false;
    } else if (event.data?.type === "log-assist-stopped") {
      window.__logAssistIsLogging = false;
      window.__logAssistHasError = false;
    }
  });


  function captureErrorScreenshot() {
    if (window.__logAssistHasError || !window.__logAssistIsLogging) return;
    window.__logAssistHasError = true;
    
    // Защита от слишком частых скриншотов (не чаще чем раз в 5 секунд)
    if (errorScreenshotTimeout) {
      clearTimeout(errorScreenshotTimeout);
    }
    
    errorScreenshotTimeout = setTimeout(() => {
      window.__logAssistHasError = false;
    }, 500);
    
    try {
      window.postMessage({ 
        source: 'log-assist', 
        type: 'error-screenshot-request'
      }, '*');
    } catch (e) {
      console.warn("Не удалось отправить запрос на скриншот:", e);
    }
  }

  // Обработчик ошибок консоли
  console.error = function (...args) {
    const simplifiedArgs = args.map(arg => {
      if (arg instanceof Error) {
        return {
          message: arg.message,
          stack: arg.stack ? arg.stack.split('\n')[0] : undefined
        };
      }
      return typeof arg === 'object' ? JSON.stringify(arg) : arg;
    });
    
    window.postMessage({ 
      source: 'log-assist', 
      type: 'console-error', 
      data: simplifiedArgs.length === 1 ? simplifiedArgs[0] : simplifiedArgs
    }, '*');
    
    captureErrorScreenshot();
    originalConsoleError.apply(console, args);
  };

  console.warn = function (...args) {
    const simplifiedArgs = args.map(arg => {
      if (arg instanceof Error) return arg.message;
      return typeof arg === 'object' ? JSON.stringify(arg) : arg;
    });
    
    window.postMessage({ 
      source: 'log-assist', 
      type: 'console-warn', 
      data: simplifiedArgs.length === 1 ? simplifiedArgs[0] : simplifiedArgs
    }, '*');
    originalConsoleWarn.apply(console, args);
  };

  // Обработчик глобальных ошибок
  window.onerror = function (msg, url, lineNo, columnNo, error) {
    window.postMessage({
      source: 'log-assist',
      type: 'onerror',
      data: {
        message: typeof msg === 'string' ? msg : 'Unknown error',
        source: url,
        line: lineNo,
        column: columnNo,
        stack: error?.stack ? error.stack.split('\n').slice(0, 2).join('\n') : undefined
      }
    }, '*');
    
    captureErrorScreenshot();
  };

  // Обработчик необработанных промисов
  window.addEventListener('unhandledrejection', function (event) {
    const reason = event.reason;
    window.postMessage({
      source: 'log-assist',
      type: 'unhandledrejection',
      data: {
        message: reason instanceof Error ? reason.message : String(reason),
        stack: reason instanceof Error && reason.stack ? reason.stack.split('\n')[0] : undefined
      }
    }, '*');
    
    captureErrorScreenshot();
  });
})();